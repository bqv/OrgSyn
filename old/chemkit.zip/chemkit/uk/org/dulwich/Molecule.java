package uk.org.dulwich;

import java.util.List;
import java.util.ArrayList;

import java.awt.*;
import java.awt.image.*;

import javax.imageio.*;
import javax.swing.*;

import org.openscience.cdk.*;
import org.openscience.cdk.interfaces.*;
import org.openscience.cdk.layout.*;
import org.openscience.cdk.renderer.*;
import org.openscience.cdk.renderer.font.*;
import org.openscience.cdk.renderer.generators.*;
import org.openscience.cdk.renderer.visitor.*;
import org.openscience.cdk.smiles.*;
import org.openscience.cdk.templates.*;

public class Molecule {

	private IMolecule molecule;
	int width;
	int height;

	public Molecule(String smiles)
	{
		this(smiles, 100, 100);
	}

	public Molecule(String smiles, int w, int h)
	{
		width = w;
		height = h;
		try {
			SmilesParser sp = new SmilesParser(DefaultChemObjectBuilder.getInstance());
			molecule = sp.parseSmiles(smiles);
		} catch (Exception ise) { ise.printStackTrace(); System.exit(1); }
	}

	private IAtomContainer generateCoordinates(IMolecule mol) throws Exception
	{
		StructureDiagramGenerator sdg = new StructureDiagramGenerator();
		sdg.setMolecule(mol);
		sdg.generateCoordinates(new javax.vecmath.Vector2d(1,0));
		return sdg.getMolecule();
	}

	public Image toImage()
	{
		Rectangle drawArea = new Rectangle(width, height);
		Image image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		IAtomContainer ac = new AtomContainer();
		try {
			ac = generateCoordinates(molecule);
		} catch (Exception e) {e.printStackTrace(); System.exit(2);}

        List<IGenerator<IAtomContainer>> generators = new ArrayList<IGenerator<IAtomContainer>>();
		generators.add(new BasicSceneGenerator());
		generators.add(new BasicBondGenerator());
		generators.add(new BasicAtomGenerator());
		generators.add(new ExtendedAtomGenerator());

		AtomContainerRenderer renderer = new AtomContainerRenderer(generators, new AWTFontManager());
        RendererModel model = renderer.getRenderer2DModel(); 
        model.set(BasicSceneGenerator.FitToScreen.class, true);
        model.set(BasicSceneGenerator.Margin.class, 10.0);
        model.set(BasicAtomGenerator.KekuleStructure.class, true);
		model.set(ExtendedAtomGenerator.ShowImplicitHydrogens.class, true);
		renderer.setup(ac, drawArea);

		Graphics2D g2d = (Graphics2D)image.getGraphics();
		g2d.setColor(Color.WHITE);
		g2d.fillRect(0, 0, width, height);

		renderer.paint(ac, new AWTDrawVisitor(g2d));
		g2d.dispose();
		return image;
	}

	public JLabel toLabel()
	{
		JLabel label = new JLabel(new ImageIcon(toImage()));
		return label;
	}
}
